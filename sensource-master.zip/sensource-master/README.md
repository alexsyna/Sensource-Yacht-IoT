A holistic smart IoT project to enable yacht owners to remotely monitor and control the condition of their boat.
